export let create: any;
//# sourceMappingURL=decoder.d.ts.map