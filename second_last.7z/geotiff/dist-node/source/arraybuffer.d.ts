export function makeBufferSource(arrayBuffer: any): ArrayBufferSource;
declare class ArrayBufferSource extends BaseSource {
    constructor(arrayBuffer: any);
    arrayBuffer: any;
}
import { BaseSource } from "./basesource.js";
export {};
//# sourceMappingURL=arraybuffer.d.ts.map