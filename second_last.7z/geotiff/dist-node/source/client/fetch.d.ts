export class FetchClient extends BaseClient {
    constructor(url: any, credentials: any);
    credentials: any;
}
import { BaseClient } from "./base.js";
//# sourceMappingURL=fetch.d.ts.map