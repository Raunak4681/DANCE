export function makeFileSource(path: any): FileSource;
declare class FileSource extends BaseSource {
    constructor(path: any);
    path: any;
    openRequest: Promise<any>;
}
import { BaseSource } from "./basesource.js";
export {};
//# sourceMappingURL=file.d.ts.map