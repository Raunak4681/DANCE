export function writeGeotiff(data: any, metadata: any): ArrayBufferLike;
//# sourceMappingURL=geotiffwriter.d.ts.map