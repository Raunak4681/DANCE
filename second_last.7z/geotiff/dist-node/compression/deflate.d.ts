export default class DeflateDecoder extends BaseDecoder {
    decodeBlock(buffer: any): any;
}
import BaseDecoder from "./basedecoder.js";
//# sourceMappingURL=deflate.d.ts.map