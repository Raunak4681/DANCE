export default class BaseDecoder {
    decode(fileDirectory: any, buffer: any): Promise<any>;
}
//# sourceMappingURL=basedecoder.d.ts.map