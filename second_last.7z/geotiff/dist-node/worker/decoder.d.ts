export function create(): Worker;
//# sourceMappingURL=decoder.d.ts.map