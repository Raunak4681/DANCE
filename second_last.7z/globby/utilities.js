export const isNegativePattern = pattern => pattern[0] === '!';
