export const hyperid: () => string;
