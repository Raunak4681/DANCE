# Installation
> `npm install --save @types/topojson-specification`

# Summary
This package contains type definitions for topojson-specification (https://github.com/topojson/topojson-specification).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/topojson-specification.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: [@types/geojson](https://npmjs.com/package/@types/geojson)

# Credits
These definitions were written by [denisname](https://github.com/denisname).
