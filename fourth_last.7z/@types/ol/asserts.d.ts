export function assert(assertion: any, errorCode: number): void;
