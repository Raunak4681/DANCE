declare enum CollectionEventType {
    ADD = 'add',
    REMOVE = 'remove',
}

export default CollectionEventType;
