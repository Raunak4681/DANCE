declare enum ObjectEventType {
    PROPERTYCHANGE = 'propertychange',
}

export default ObjectEventType;
