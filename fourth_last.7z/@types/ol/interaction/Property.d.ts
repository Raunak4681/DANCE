declare enum Property {
    ACTIVE = 'active',
}

export default Property;
