/**
 * Check if the linestring is a boundary.
 */
export function lineStringIsClosed(flatCoordinates: number[], offset: number, end: number, stride: number): boolean;
