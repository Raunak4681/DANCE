export function linearRing(flatCoordinates: number[], offset: number, end: number, stride: number): number;
export function linearRings(flatCoordinates: number[], offset: number, ends: number[], stride: number): number;
export function linearRingss(flatCoordinates: number[], offset: number, endss: number[][], stride: number): number;
