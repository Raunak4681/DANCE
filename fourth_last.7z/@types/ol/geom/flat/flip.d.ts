export function flipXY(
    flatCoordinates: number[],
    offset: number,
    end: number,
    stride: number,
    opt_dest?: number[],
    opt_destOffset?: number,
): number[];
