export function coordinates(flatCoordinates: number[], offset: number, end: number, stride: number): void;
