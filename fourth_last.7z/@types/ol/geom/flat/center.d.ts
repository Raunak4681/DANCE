export function linearRingss(flatCoordinates: number[], offset: number, endss: number[][], stride: number): number[];
