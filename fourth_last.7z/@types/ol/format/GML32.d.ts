import GML3 from './GML3';
import { Options } from './GMLBase';

export default class GML32 extends GML3 {
    constructor(opt_options?: Options);
}
