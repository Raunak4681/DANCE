import XML from './XML';

export default class WMSCapabilities extends XML {
    constructor();
    readFromNode(node: Element): any;
}
