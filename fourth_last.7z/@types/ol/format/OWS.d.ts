import XML from './XML';

export default class OWS extends XML {
    constructor();
    readFromNode(node: Element): any;
}
