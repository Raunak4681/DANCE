import Filter from './Filter';

export default class Not extends Filter {
    constructor(condition: Filter);
}
