import ComparisonBinary from './ComparisonBinary';

export default class GreaterThan extends ComparisonBinary {
    constructor(propertyName: string, expression: number);
}
