import ComparisonBinary from './ComparisonBinary';

export default class LessThan extends ComparisonBinary {
    constructor(propertyName: string, expression: number);
}
