import Comparison from './Comparison';

export default class IsNull extends Comparison {
    constructor(propertyName: string);
}
