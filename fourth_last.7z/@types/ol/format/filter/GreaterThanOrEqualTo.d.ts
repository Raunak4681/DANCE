import ComparisonBinary from './ComparisonBinary';

export default class GreaterThanOrEqualTo extends ComparisonBinary {
    constructor(propertyName: string, expression: number);
}
