import ComparisonBinary from './ComparisonBinary';

export default class LessThanOrEqualTo extends ComparisonBinary {
    constructor(propertyName: string, expression: number);
}
