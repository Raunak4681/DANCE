import Filter from './Filter';

export default abstract class ResourceId extends Filter {
    constructor(rid: string);
}
