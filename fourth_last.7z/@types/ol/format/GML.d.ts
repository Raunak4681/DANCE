import { Options } from './GMLBase';

declare const GML: (opt_options?: Options) => void;

export default GML;
