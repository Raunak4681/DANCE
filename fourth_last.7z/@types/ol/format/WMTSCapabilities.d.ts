import XML from './XML';

export default class WMTSCapabilities extends XML {
    constructor();
    readFromNode(node: Element): any;
}
