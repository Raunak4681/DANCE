export function readHref(node: Element): string | undefined;
