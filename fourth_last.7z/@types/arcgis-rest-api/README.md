# Installation
> `npm install --save @types/arcgis-rest-api`

# Summary
This package contains type definitions for arcgis-rest-api (http://resources.arcgis.com/en/help/arcgis-rest-api/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/arcgis-rest-api.

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:04 GMT
 * Dependencies: none

# Credits
These definitions were written by [Jeff Jacobson](https://github.com/JeffJacobson).
