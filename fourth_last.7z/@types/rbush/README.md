# Installation
> `npm install --save @types/rbush`

# Summary
This package contains type definitions for rbush (https://github.com/mourner/rbush).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/rbush.

### Additional Details
 * Last updated: Thu, 26 Sep 2024 17:08:07 GMT
 * Dependencies: none

# Credits
These definitions were written by [Dan Vanderkam](https://github.com/danvk), and [Chris Lewis](https://github.com/cmslewis).
