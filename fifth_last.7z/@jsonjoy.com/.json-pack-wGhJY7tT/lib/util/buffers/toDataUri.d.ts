export declare const toDataUri: (buf: Uint8Array, params?: Record<string, string | number>) => string;
