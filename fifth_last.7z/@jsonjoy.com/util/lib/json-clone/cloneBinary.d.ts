export declare const cloneBinary: <T = unknown>(obj: T) => T;
