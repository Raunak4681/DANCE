export declare const clone: <T = unknown>(obj: T) => T;
