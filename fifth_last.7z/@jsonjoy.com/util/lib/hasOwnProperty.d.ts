export declare function hasOwnProperty(obj: object, key: string): boolean;
