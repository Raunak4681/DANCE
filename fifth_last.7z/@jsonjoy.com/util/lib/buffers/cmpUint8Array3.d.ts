export declare const cmpUint8Array3: (a: Uint8Array, b: Uint8Array) => number;
