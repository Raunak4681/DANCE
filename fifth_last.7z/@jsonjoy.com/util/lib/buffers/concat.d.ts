export declare const concat: (a: Uint8Array, b: Uint8Array) => Uint8Array;
export declare const concatList: (list: Uint8Array[]) => Uint8Array;
export declare const listToUint8: (list: Uint8Array[]) => Uint8Array;
