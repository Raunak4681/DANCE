export declare const cmpUint8Array: (a: Uint8Array, b: Uint8Array) => boolean;
