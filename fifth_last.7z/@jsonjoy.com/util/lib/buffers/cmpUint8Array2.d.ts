export declare const cmpUint8Array2: (a: Uint8Array, b: Uint8Array) => number;
