export declare const decodeF16: (binary: number) => number;
