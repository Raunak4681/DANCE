export declare const decodeAscii: (src: Uint8Array, position: number, length: number) => string | undefined;
export declare const decodeAsciiMax15: (src: Uint8Array, position: number, length: number) => string | undefined;
