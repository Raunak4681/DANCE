export declare class CachedUtf8Decoder {
    private readonly caches;
    constructor();
    private get;
    private store;
    decode(bytes: Uint8Array, offset: number, size: number): string;
}
