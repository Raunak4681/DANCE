import decodeUtf8 from './v16';
export { decodeUtf8 };
