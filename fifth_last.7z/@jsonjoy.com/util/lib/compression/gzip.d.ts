export declare const gzip: (data: Uint8Array) => Promise<Uint8Array>;
export declare const ungzip: (data: Uint8Array) => Promise<Uint8Array>;
