import * as type from './types';
export declare const JSON: type.JSON;
export type { json, json_string } from './types';
