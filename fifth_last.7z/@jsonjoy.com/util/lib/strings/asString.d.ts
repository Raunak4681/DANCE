export declare const asString: (str: string) => string;
