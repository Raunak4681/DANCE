export declare const escape: (str: string) => string;
