export declare const fromStream: (stream: ReadableStream<Uint8Array>) => Promise<Uint8Array>;
