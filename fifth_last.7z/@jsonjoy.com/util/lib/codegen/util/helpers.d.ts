export declare const emitStringMatch: (expression: string, offset: string, match: string) => string;
