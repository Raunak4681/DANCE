export declare const deepEqual: (a: unknown, b: unknown) => boolean;
