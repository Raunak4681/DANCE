import { JavaScript } from '../../codegen';
export declare const $$deepEqual: (a: unknown) => JavaScript<(b: unknown) => boolean>;
