export declare const normalizeAccessor: (accessor: string) => string;
