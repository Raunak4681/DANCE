declare const _default: (buf: Uint8Array, start: number, length: number) => string;
export default _default;
