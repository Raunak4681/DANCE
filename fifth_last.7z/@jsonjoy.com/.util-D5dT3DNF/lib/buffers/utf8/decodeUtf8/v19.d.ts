declare const readUtf8: any;
export default readUtf8;
