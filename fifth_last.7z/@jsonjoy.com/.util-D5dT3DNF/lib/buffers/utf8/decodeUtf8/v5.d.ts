declare const _default: (uint8: Uint8Array, start: number, length: number) => string;
export default _default;
