type Decoder = (buf: Uint8Array, start: number, length: number) => string;
declare const decoder: Decoder;
export default decoder;
