declare let decode: (buf: Uint8Array, start: number, length: number) => string;
export default decode;
