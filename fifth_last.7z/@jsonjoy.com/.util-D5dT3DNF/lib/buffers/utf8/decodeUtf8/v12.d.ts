declare const _default: (arr: Uint8Array, start: number, length: number) => string;
export default _default;
