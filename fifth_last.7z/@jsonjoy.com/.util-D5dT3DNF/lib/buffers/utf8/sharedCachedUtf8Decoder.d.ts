import { CachedUtf8Decoder } from './CachedUtf8Decoder';
declare const _default: CachedUtf8Decoder;
export default _default;
