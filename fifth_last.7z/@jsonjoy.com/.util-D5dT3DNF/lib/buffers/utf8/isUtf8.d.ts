export declare const isUtf8: (buf: Uint8Array, from: number, length: number) => boolean;
