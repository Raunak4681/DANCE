export declare const flatstr: (s: string) => string;
