export declare const b: (...args: number[]) => Uint8Array;
