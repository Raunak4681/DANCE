export declare const createToBase64Bin: (chars?: string, pad?: string) => (uint8: Uint8Array, start: number, length: number, dest: DataView, offset: number) => number;
