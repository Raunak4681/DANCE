export declare const fromBase64Url: (encoded: string) => Uint8Array;
