export declare const fromBase64Bin: (view: DataView, offset: number, length: number) => Uint8Array;
