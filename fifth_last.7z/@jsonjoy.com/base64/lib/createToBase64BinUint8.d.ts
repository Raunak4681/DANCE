export declare const createToBase64BinUint8: (chars?: string, pad?: string) => (uint8: Uint8Array, start: number, length: number, dest: Uint8Array, offset: number) => number;
