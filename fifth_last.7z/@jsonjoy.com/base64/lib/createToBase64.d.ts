export declare const createToBase64: (chars?: string, pad?: string) => (uint8: Uint8Array, length: number) => string;
