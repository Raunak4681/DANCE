export declare const createFromBase64: (chars?: string, noPadding?: boolean) => (encoded: string) => Uint8Array;
