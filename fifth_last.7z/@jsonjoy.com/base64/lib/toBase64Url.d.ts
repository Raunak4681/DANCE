export declare const toBase64Url: (uint8: Uint8Array, length: number) => string;
