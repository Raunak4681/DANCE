import { CborEncoderStable } from './CborEncoderStable';
export declare class CborEncoderDag extends CborEncoderStable {
    writeUndef(): void;
    writeFloat(float: number): void;
    writeTag(tag: number, value: unknown): void;
}
