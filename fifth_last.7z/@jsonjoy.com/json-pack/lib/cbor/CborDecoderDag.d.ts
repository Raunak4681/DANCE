import { JsonPackExtension } from '../JsonPackExtension';
import { CborDecoder } from './CborDecoder';
export declare class CborDecoderDag extends CborDecoder {
    readTagRaw(tag: number): JsonPackExtension<unknown> | unknown;
}
