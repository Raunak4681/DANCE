export declare const binUriStart = "data:application/octet-stream;base64,";
export declare const msgPackUriStart: string;
export declare const msgPackExtStart: string;
