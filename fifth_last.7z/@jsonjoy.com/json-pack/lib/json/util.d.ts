export declare const findEndingQuote: (uint8: Uint8Array, x: number) => number;
