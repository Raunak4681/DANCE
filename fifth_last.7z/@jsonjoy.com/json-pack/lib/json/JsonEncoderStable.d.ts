import { JsonEncoder } from './JsonEncoder';
export declare class JsonEncoderStable extends JsonEncoder {
    writeObj(obj: Record<string, unknown>): void;
}
