export declare const enum TYPE {
    NULL = 0,
    BOOL = 1,
    UINT = 2,
    NINT = 3,
    FLOT = 4,
    STRI = 8,
    LIST = 11,
    BINA = 10,
    STRU = 13,
    ANNO = 14
}
export declare const enum TYPE_OVERLAY {
    NULL = 0,
    BOOL = 16,
    UINT = 32,
    NINT = 48,
    FLOT = 64,
    STRI = 128,
    LIST = 176,
    BINA = 160,
    STRU = 208,
    ANNO = 224
}
