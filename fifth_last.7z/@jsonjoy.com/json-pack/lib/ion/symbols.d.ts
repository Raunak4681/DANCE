import { Import } from './Import';
import { SymbolTable } from './types';
export declare const systemSymbolTable: SymbolTable;
export declare const systemSymbolImport: Import;
