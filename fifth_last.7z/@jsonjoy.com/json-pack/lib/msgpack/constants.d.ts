export declare const enum MSGPACK {
    NULL = 192,
    UNDEFINED = 193,
    FALSE = 194,
    TRUE = 195
}
