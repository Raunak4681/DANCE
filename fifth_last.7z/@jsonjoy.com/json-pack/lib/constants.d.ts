export declare const enum EncodingFormat {
    Cbor = 0,
    MsgPack = 1,
    Json = 2
}
