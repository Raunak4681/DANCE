export declare class DecompressionTable {
    protected readonly table: unknown[];
    importTable(rleTable: unknown[]): void;
    getLiteral(index: number): unknown;
    decompress(value: unknown): unknown;
}
