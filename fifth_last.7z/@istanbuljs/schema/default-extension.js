'use strict';

module.exports = [
	'.js',
	'.cjs',
	'.mjs',
	'.ts',
	'.tsx',
	'.jsx'
];
