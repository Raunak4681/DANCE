package com.radar.repository;

import com.radar.model.ElevationData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.locationtech.jts.geom.Geometry;

import java.util.List;

public interface ElevationDataRepository extends JpaRepository<ElevationData, Long> {
    @Query(value = """
        SELECT e FROM ElevationData e
        WHERE ST_Intersects(e.boundary, :area)
        ORDER BY e.rastDate DESC
    """)
    List<ElevationData> findByIntersectingArea(@Param("area") Geometry area);

    @Query(value = """
        SELECT ST_Value(e.rast, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326))
        FROM ElevationData e
        WHERE ST_Intersects(e.rast, ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326))
        ORDER BY e.rastDate DESC
        LIMIT 1
    """)
    Double getElevationAtPoint(
        @Param("longitude") double longitude,
        @Param("latitude") double latitude
    );

    @Query(value = """
        WITH RECURSIVE points AS (
            SELECT 
                ST_MakePoint(x.lon, y.lat) AS point,
                ST_Value(e.rast, ST_MakePoint(x.lon, y.lat)) AS elevation
            FROM 
                generate_series(:longitude - :range/111.0, :longitude + :range/111.0, 0.001) AS x(lon),
                generate_series(:latitude - :range/111.0, :latitude + :range/111.0, 0.001) AS y(lat),
                ElevationData e
            WHERE 
                ST_Intersects(e.rast, ST_MakePoint(x.lon, y.lat))
        ),
        visible_points AS (
            SELECT p.point
            FROM points p
            WHERE ST_Distance(
                ST_SetSRID(ST_MakePoint(:longitude, :latitude), 4326),
                p.point
            ) * 111.0 <= :range
            AND NOT EXISTS (
                SELECT 1
                FROM points p2
                WHERE ST_MakeLine(
                    ST_MakePoint(:longitude, :latitude),
                    p.point
                ) && ST_MakePoint(p2.point[0], p2.point[1])
                AND p2.elevation > (
                    p.elevation + (ST_Distance(p.point, ST_MakePoint(:longitude, :latitude)) * 111000) * tan(radians(20))
                )
            )
        )
        SELECT ST_AsText(ST_ConcaveHull(ST_Collect(point), 0.98))
        FROM visible_points
    """)
    String getTerrainAwareRadarCoverage(
        @Param("longitude") double longitude,
        @Param("latitude") double latitude,
        @Param("range") double range
    );
}