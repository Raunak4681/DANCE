import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Geometry } from 'ol/geom';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import ImageLayer from 'ol/layer/Image';
import Static from 'ol/source/ImageStatic';
import TileWMS from 'ol/source/TileWMS';
import { Circle as CircleStyle, Fill, Stroke, Style } from 'ol/style';
import { Vector as VectorLayer } from 'ol/layer';
import { Vector as VectorSource } from 'ol/source';
import Feature from 'ol/Feature';
import Point from 'ol/geom/Point';
import { fromLonLat } from 'ol/proj';
import { defaults as defaultControls } from 'ol/control';
import GeoJSON from 'ol/format/GeoJSON';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-map',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit, OnDestroy {
  constructor(private http: HttpClient) {}
  private map!: Map;
  private vectorLayer!: VectorLayer<VectorSource>;
  private vectorSource!: VectorSource;
  
  // Radar parameters
  radarParams = {
    latitude: 51.5074,
    longitude: -0.1278,
    radius: 50, // km
    elevation: 30, // meters
    tilt: 0 // degrees
  };

  ngOnInit() {
    this.initializeMap();
    this.initializeVectorLayer();
    this.updateRadarCoverage();
  }

  ngOnDestroy() {
    if (this.map) {
      this.map.dispose();
    }
  }

  private initializeMap() {
    this.map = new Map({
      target: 'map',
      layers: [
        new TileLayer({
          source: new TileWMS({
            url: 'http://localhost:8080/geoserver/ne/wms',
            params: {
              'LAYERS': 'ne:NE1_HR_LC_SR_W_DR',
              'VERSION': '1.1.0',
              'FORMAT': 'image/png',
              'TILED': true
            },
            serverType: 'geoserver',
            projection: 'EPSG:4326'
          })
        }),
        new TileLayer({
          source: new TileWMS({
            url: 'http://localhost:8080/geoserver/radar/wms',
            params: {
              'LAYERS': 'radar:elevation',
              'VERSION': '1.1.0',
              'FORMAT': 'image/png',
              'TILED': true
            },
            serverType: 'geoserver',
            projection: 'EPSG:4326'
          })
        }),
        new ImageLayer({
          source: new Static({
            url: 'assets/elevation.tif',
            imageExtent: [-180, -90, 180, 90],
            projection: 'EPSG:4326'
          }),
          opacity: 0.6,
          visible: true
        })
      ],
      controls: defaultControls({
        attribution: true,
        zoom: true,
      }),
      view: new View({
        center: fromLonLat([this.radarParams.longitude, this.radarParams.latitude]),
        zoom: 8
      })
    });
  }

  private initializeVectorLayer() {
    this.vectorSource = new VectorSource();
    this.vectorLayer = new VectorLayer({
      source: this.vectorSource,
      style: new Style({
        image: new CircleStyle({
          radius: 8,
          fill: new Fill({ color: '#FF4444' }),
          stroke: new Stroke({ color: 'white', width: 2 })
        })
      })
    });
    this.map.addLayer(this.vectorLayer);
  }

  private updateRadarCoverage() {
    if (!this.vectorSource) {
      console.warn('Vector source not initialized');
      return;
    }

    this.vectorSource.clear();
    
    // Add radar point with custom style
    const radarPoint = new Feature({
      geometry: new Point(fromLonLat([this.radarParams.longitude, this.radarParams.latitude]))
    });
    
    const radarPointStyle = new Style({
      image: new CircleStyle({
        radius: 8,
        fill: new Fill({ color: '#FF4444' }),
        stroke: new Stroke({ color: 'white', width: 2 })
      })
    });
    radarPoint.setStyle(radarPointStyle);
    
    // Fetch terrain-aware coverage from backend
    this.http.get(`${environment.apiUrl}/radar/coverage`, {
      params: {
        longitude: this.radarParams.longitude.toString(),
        latitude: this.radarParams.latitude.toString(),
        range: this.radarParams.radius.toString()
      }
    }).subscribe({
      next: (coverage: any) => {
        try {
          // Convert GeoJSON coverage to OpenLayers feature
          const format = new GeoJSON();
          const coverageFeature = format.readFeature(coverage, {
            featureProjection: 'EPSG:3857'
          }) as Feature<Geometry>;

          const coverageStyle = new Style({
            fill: new Fill({
              color: 'rgba(255, 68, 68, 0.2)'
            }),
            stroke: new Stroke({
              color: '#FF4444',
              width: 2
            })
          });

          if (coverageFeature instanceof Feature) {
            coverageFeature.setStyle(coverageStyle);
            // Add features one by one to ensure proper addition
            this.vectorSource.addFeature(radarPoint);
            this.vectorSource.addFeature(coverageFeature);
          }
          this.goToLocation();
        } catch (error) {
          console.error('Error processing coverage data:', error);
        }
      },
      error: (error: Error) => {
        console.error('Error fetching radar coverage:', error);
        // Still show the radar point even if coverage fetch fails
        this.vectorSource.addFeature(radarPoint);
      }
    });
  }

  goToLocation() {
    const view = this.map.getView();
    view.animate({
      center: fromLonLat([this.radarParams.longitude, this.radarParams.latitude]),
      zoom: 12,
      duration: 2000,
      easing: function (t) {
        return Math.pow(2, -10 * t) * Math.sin((t - 0.075) * (2 * Math.PI) / 0.3) + 1;
      }
    });
  }

  onParamsChange() {
    this.updateRadarCoverage();
  }
}